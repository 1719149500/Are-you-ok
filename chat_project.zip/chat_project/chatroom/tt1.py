"""
# -*- coding: utf-8 -*-
# @Time : 2023/9/18 20:03
# @Author : 笑忘书
# @File : tt1.py
# @Project : chat_project
"""
from django.db import connections
from django.conf import settings

settings.configure(
    DEBUG=True,

)
# 获取 "default" 数据库的 IP 地址
ip_address = connections['default'].settings_dict['HOST']
print(ip_address)

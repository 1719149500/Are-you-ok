"""
# -*- coding: utf-8 -*-
# @Time : 2023/9/18 18:20
# @Author : 笑忘书
# @File : ask.py
# @Project : chat_project
"""
from django.core.serializers import json
from django.http import JsonResponse
from chatroom.models import Question

def ask(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        message = data.get('message', '')

        # 在数据库中查找匹配用户问题的回答
        question = Question.objects.filter(question_text=message).first()
        if question:
            answer = question.answer_text
        else:
            answer = 'Sorry, I cannot answer that question.'

        return JsonResponse({'answer': answer})

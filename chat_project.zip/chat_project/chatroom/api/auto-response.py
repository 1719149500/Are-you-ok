"""
# -*- coding: utf-8 -*-
# @Time : 2023/9/18 18:24
# @Author : 笑忘书
# @File : auto-response.py
# @Project : chat_project
"""
from django.http import JsonResponse
from chatroom.models import ResponseText

def get_auto_response(request):
    response_texts = ResponseText.objects.all().values('text')
    return JsonResponse(list(response_texts), safe=False)



from django.db import models
from django.shortcuts import render

#用户表
from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission


class CustomUser(AbstractUser):
    id = models.AutoField(primary_key=True)
    phone_number = models.CharField(max_length=15)
    email = models.EmailField()
    groups = models.ManyToManyField(
        Group,
        verbose_name=("groups"),
        blank=True,
        help_text=(
            "The groups this user belongs to. A user will get all permissions "
            "granted to each of their groups."
        ),
        related_name='custom_users'  # 添加一个与 'auth.User.groups' 不冲突的 related_name
    )
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=('user permissions'),
        blank=True,
        help_text=('Specific permissions for this user.'),
        related_name='custom_users_permissions'  # 添加一个与 'auth.User.user_permissions' 不冲突的 related_name
    )
    def __str__(self):
        return self.username


class Admin(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    password = models.CharField(max_length=255)

    def __str__(self):
        return self.name


#统计数据表
class Statistics(models.Model):
    user_ip = models.CharField(max_length=30,verbose_name="用户IP")
    user_brower = models.CharField(max_length=500,verbose_name="用户浏览器类型")
    date = models.DateTimeField(verbose_name="用户上线时间")


#用户应答信息表
class Answer_data(models.Model):
    data_id = models.AutoField(primary_key=True,verbose_name="特定数据id")
    key_words = models.CharField(max_length=30,verbose_name="关键字")
    reply = models.CharField(max_length=100,verbose_name="回复文字")
    user_image = models.ImageField(upload_to='media/',verbose_name="图片", null=True)
    url = models.CharField(max_length=100, verbose_name="超链接")

#用户上传信息表
class user_data(models.Model):
    id = models.AutoField(primary_key=True,verbose_name="输入数据id")
    words = models.CharField(max_length=30,verbose_name="用户输入的文字")
    image = models.ImageField(upload_to='upload/',verbose_name="用户上传的图片")

#问答数据表
class Question(models.Model):
    question_text = models.CharField(max_length=200)
    answer_text = models.TextField()
    id = models.AutoField(primary_key=True)
class ResponseText(models.Model):
    text = models.TextField()

    def __str__(self):
        return self.text

"""
# -*- coding: utf-8 -*-
# @Time : 2023/9/18 16:17
# @Author : 笑忘书
# @File : urls.py
# @Project : chat_project
"""
from django.urls import path
from .views import chatroom

app_name = 'chatroom'

urlpatterns = [
    # 其他 URL 配置
    path('chatroom/', chatroom, name='chatroom'),
]
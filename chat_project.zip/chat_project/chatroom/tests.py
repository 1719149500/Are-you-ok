

# Create your tests here.
import pymysql

from django.conf import settings

settings.configure(
    DEBUG=True,

)


def test_mysql_connection():
    try:
        conn = pymysql.connect(
            host=settings.DATABASES['default']['HOST'],
            port=int(settings.DATABASES['default']['PORT']),
            user=settings.DATABASES['default']['USER'],
            password=settings.DATABASES['default']['PASSWORD'],
            db=settings.DATABASES['default']['NAME'],
        )
        print("MySQL 连接成功！")
        conn.close()
    except pymysql.Error as e:
        print("MySQL 连接失败:", str(e))


if __name__ == "__main__":
    test_mysql_connection()
